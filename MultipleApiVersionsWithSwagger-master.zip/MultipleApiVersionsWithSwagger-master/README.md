# Documenting API Versions with Swagger
Asp.Net Core REST API with multiple versions. And swagger is used to document the api

Please check [this post](https://cabbagetech.blog/2019/03/02/integrating-swagger-with-url-based-asp-net-core-api-versioning/) for more details

Master branch has been upgraded to ASP.Net Core 3.1. If you are after ASP.Net Core 2.2 please check the branch [AspNetCore2.2](https://github.com/jobairkhan/MultipleApiVersionsWithSwagger/tree/AspNetCore2.2)
